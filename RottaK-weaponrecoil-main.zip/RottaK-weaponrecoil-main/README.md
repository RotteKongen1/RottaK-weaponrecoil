# FiveM Weapon Recoil Script

A simple and configurable weapon recoil script for **FiveM**, made by **RottaK**.

## Features
- Custom weapon recoil handling  
- Smooth and realistic recoil behavior  
- Optimized for performance  
- Easy to configure and extend  

## Framework
- ✅ **Qbox (QBX)** compatible  
- ❌ Not made for QBCore / ESX by default  

## Installation
1. Download the script  
2. Place it in your `resources` folder  
3. Add it to `server.cfg`:
   ```
   ensure yourscriptname
   ```

## Configuration
Edit the config file to adjust recoil values per weapon.

## Credits
- Script made by **RottaK**

## License
Free to use. Do not reupload or claim as your own.
